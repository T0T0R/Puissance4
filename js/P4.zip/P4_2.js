/*** INITIALISATION ***/

var JEU = [[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0]];	//JEU = [ligne0, ligne1, ligne2, ligne3, ligne4, ligne5]

var player=1;
var cote=100;	//La largeur de la case.



while (true){	//Boucle principale
	player=1;
	effaceEcranG(0);
	AfficheGrille();
	SaisieColonne();
	if (Termine()){
		AfficheGrille();
		break;
    }
	
	player=2;
	effaceEcranG(0);
	AfficheGrille();
	SaisieColonne();
	if (Termine()){
		AfficheGrille();
		break;
    }
}



function AfficheGrille(){
	effaceEcranG(0);
	RectanglePlein(0,0,7*cote+7,6*cote+6,'black');
	Ligne(1,0,0,6*cote+6,'white');

	for (var i = 0; i < 6; i++) {
		
		Ligne(0,i*cote+i,cote*7+7,i*cote+i,'white');
		for (var j = 0; j < 7; j++) {
			Ligne((j+1)*cote+j,0,(j+1)*cote+j,6*cote+6,'white');
			if (JEU[i][j]==1){
				CerclePlein(cote*(j+0.5)+j,cote*(i+0.5)+i,cote-10,'red');
			}else if (JEU[i][j]==2){
				CerclePlein(cote*(j+0.5)+j,cote*(i+0.5)+i,cote-10,'yellow');				
			}
		}

	}
}



function afficheTexteG(texte){
	effaceEcranG(7*cote);
	Texte(10, 8*cote, texte, 'black');
}



function effaceEcranG(hauteur){
	RectanglePlein(0,hauteur,10*cote,hauteur,'white'); 
}



function AfficheGrilleDebug(){
	for (var i = 0; i < 6; i++) {
		var ligne ="";
		for (var j = 0; j < 7; j++) {
			if (JEU[i][j]==0){
				ligne +=String("_");
			}else if (JEU[i][j]==1){
				ligne +=String("1");
			}else if (JEU[i][j]==2){
				ligne +=String("2");
			}
		}
		Ecrire(ligne);
	}
}



function SaisieColonne(){
	var saisir = 1;
	if (player===1){
		var str="rouge";
    }else{
		var str="jaune";
    }
	while (saisir===1){
		var colonne = SaisieEntier("Joueur "+str+", entrez la colonne de votre choix :")-1;
		for (var i = 0; i < 6; i++) {
			if (JEU[5-i][colonne]===0) {	//Si la case (6-i,colonne) est libre
				JEU[5-i][colonne]=player;
				saisir = 2;
				break;
			}else if (colonne<0 ||colonne>8){	//Si le numero de la colonne est incorrect
				afficheTexteG("Entrée éronnée");
				break;
			}else if (i===5) {	//Si la case (5,colonne) n'est pas vide
				afficheTexteG("Colonne pleine");
				break;
			}			
		}
	}
}



function Termine(){
	//Pour Rouge:
	if (verifLigne(1)){
		effaceEcranG(0);
		afficheTexteG("Le joueur rouge a gagné");
		return true;
	}
	if (verifColonne(1)){
		effaceEcranG(0);
		afficheTexteG("Le joueur rouge a gagné");
		return true;
	}
	if (verifDiag(1)){
		effaceEcranG(0);
		afficheTexteG("Le joueur rouge a gagné");
		return true;
	}

	//Pour jaune:
	if (verifLigne(2)){
		effaceEcranG(0);
		afficheTexteG("Le joueur jaune a gagné");
		return true;
	}
	if (verifColonne(2)){
		effaceEcranG(0);
		afficheTexteG("Le joueur jaune a gagné");
		return true;
	}
	if (verifDiag(2)){
		effaceEcranG(0);
		afficheTexteG("Le joueur jaune a gagné");
		return true;
	}

	var vide=0;	//Si vide=0, alors le tableau est plein.
	for (var i = 0; i < 6; i++) {
		for (var j = 0; j < 7; j++) {
			if (JEU[i][j]===0){vide++;}	//Si la premiere case d'une ligne n'est pas celle du joueur, alors le compteur de jetons du joueur dans une ligne est remis a 0.
		}
	}
	if (vide ===0){
		afficheTexteG("Plus de place");
		return true;
	}
	return false;
}



function verifLigne(player){
	for (var i = 0; i < 6; i++) {
		for (var j = 0; j < 4; j++) {	//On va de la colonne 1 a la 4.
			if (JEU[i][j]===player && JEU[i][j+1]===player && JEU[i][j+2]===player && JEU[i][j+3]===player){return true;}	//Si il existe une serie de 4 valeurs identiques.
		}
	}
	return false;
}


function verifColonne(player){
	for (var j = 0; j < 7; j++) {
		for (var i = 0; i < 3; i++) {
			if (JEU[i][j]==player && JEU[i+1][j]==player && JEU[i+2][j]==player && JEU[i+3][j]==player){return true;}	//Si il existe une serie de 4 valeurs identiques.
		}
	}
	return false;
}


function verifDiag(player){
	//Dans un sens
	for (var j = 1; j < 4; j++) {
		for (var i = 0; i < 3-j; i++) {
			if (JEU[i][j+i]==player && JEU[i+1][j+i+1]==player && JEU[i+2][j+i+2]==player && JEU[i+3][j+i+3]==player){return true;}	//Si il existe une serie de 4 valeurs identiques.
		}
	}
	for (var i = 0; i < 3; i++) {
		for (var j = 0; j < 3-i; j++) {
			if (JEU[i][j+i]==player && JEU[i+1][j+i+1]==player && JEU[i+2][j+i+2]==player && JEU[i+3][j+i+3]==player){return true;}	//Si il existe une serie de 4 valeurs identiques.
		}
	}

	//Dans l'autre sens
	for (var j = 1; j < 4; j++) {
		for (var i = 0; i < 3-j; i++) {
			if (JEU[5-i][j+i]==player && JEU[5-i-1][j+i+1]==player && JEU[5-i-2][j+i+2]==player && JEU[5-i-3][j+i+3]==player){return true;}	//Si il existe une serie de 4 valeurs identiques.
		}
	}
	for (var i = 0; i < 3; i++) {
		for (var j = 0; j < 3-i; j++) {
			if (JEU[5-i-j][j+i]==player && JEU[4-i-j][j+i+1]==player && JEU[3-i-j][j+i+2]==player && JEU[2-i-j][j+i+3]==player){return true;}	//Si il existe une serie de 4 valeurs identiques.
		}
	}
	
	return false;
}
